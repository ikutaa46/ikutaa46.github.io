<?php

class pluginDisqusLazy extends Plugin {

	public function init()
	{
		$this->dbFields = array(
			'shortname'=>'',
            'enablePages'=>false,
            'enablePosts'=>true,
			'enableLazy'=>false,
			'enableOnClick'=>false,
		);
	}

	public function form()
	{
		global $Language;

		$html  = '<div>';
		$html .= '<label>'.$Language->get('disqus-shortname').'</label>';
		$html .= '<input name="shortname" id="jsshortname" type="text" value="'.$this->getValue('shortname').'">';
		$html .= '</div>';

                $html .= '<div>';
                $html .= '<label>'.$Language->get('enable-disqus-on-pages').'</label>';
                $html .= '<select name="enablePages">';
                $html .= '<option value="true" '.($this->getValue('enablePages')===true?'selected':'').'>'.$Language->get('enabled').'</option>';
                $html .= '<option value="false" '.($this->getValue('enablePages')===false?'selected':'').'>'.$Language->get('disabled').'</option>';
                $html .= '</select>';
                $html .= '</div>';
                $html .= '<div>';
                $html .= '<label>'.$Language->get('enable-disqus-on-posts').'</label>';
                $html .= '<select name="enablePosts">';
                $html .= '<option value="true" '.($this->getValue('enablePosts')===true?'selected':'').'>'.$Language->get('enabled').'</option>';
                $html .= '<option value="false" '.($this->getValue('enablePosts')===false?'selected':'').'>'.$Language->get('disabled').'</option>';
                $html .= '</select>';
                $html .= '</div>';
				$html .= '<div>';
                $html .= '<label>'.$Language->get('enable-disqus-lazy').'</label>';
                $html .= '<select name="enableLazy">';
                $html .= '<option value="true" '.($this->getValue('enableLazy')===true?'selected':'').'>'.$Language->get('enabled').'</option>';
                $html .= '<option value="false" '.($this->getValue('enableLazy')===false?'selected':'').'>'.$Language->get('disabled').'</option>';
                $html .= '</select>';
                $html .= '</div>';
				$html .= '<div>';
                $html .= '<label>'.$Language->get('enable-disqus-on-click').'</label>';
                $html .= '<select name="enableOnClick">';
                $html .= '<option value="true" '.($this->getValue('enableOnClick')===true?'selected':'').'>'.$Language->get('enabled').'</option>';
                $html .= '<option value="false" '.($this->getValue('enableOnClick')===false?'selected':'').'>'.$Language->get('disabled').'</option>';
				$html .= '</select>';
                $html .= '<span class="tip">'.$Language->get('tip-for-lazy').'</span>';
				$html .= '</div>';

		return $html;
	}

	public function pageEnd()
	{
		global $content;
		global $url, $page;

		$page = $content[0];
		if (empty($page)) {
			return false;
		}

		if ( !$url->notFound() &&
		     ( $url->whereAmI()=='page' &&
			(($this->getValue('enablePosts') && $page->published()) ||
			($this->getValue('enablePages') && $page->isStatic()))
		     ) && 
		     $page->allowComments() ) {
				 if (!$this->getValue('enableLazy')) {
					$html  = '<div id="disqus_thread"></div>';
					$html .= '<script type="text/javascript">var disqus_config=function (){this.page.url="'.$page->permalink().'";this.page.identifier="'.$page->uuid().'";};(function(){var d=document, s=d.createElement("script");s.src="https://'.$this->getValue('shortname').'.disqus.com/embed.js";s.setAttribute("data-timestamp", +new Date());(d.head || d.body).appendChild(s);})();</script>';
				 } else {			
					$html  = '<div id="disqus_thread"><button onclick="disqus();return false;">Show Comments</button></div>';
					$html .= '<script type="text/javascript">var disqus_shortname="'.$this->getValue('shortname').'",disqus_loaded=!1;function disqus(){if(!disqus_loaded){disqus_loaded=!0;var e=document.createElement("script");e.type="text/javascript",e.async=!0,e.src="//"+disqus_shortname+".disqus.com/embed.js",(document.getElementsByTagName("head")[0]||document.getElementsByTagName("body")[0]).appendChild(e)}}</script>';
					if (!$this->getValue('enableOnClick')) {
						$html .= '<script type="text/javascript">window.onscroll=function(o){window.innerHeight+window.scrollY>=document.body.offsetHeight&&(disqus_loaded||disqus())};</script>';
					}
				 }
			return $html;
		}

		return false;
	}

}
